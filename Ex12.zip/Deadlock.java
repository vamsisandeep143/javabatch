package com;

public class Deadlock  {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
Object train = new Object();
Object comparment = new Object();

bookticket obj1 = new bookticket(train,comparment);
cancelticket obj2 = new cancelticket(train,comparment);

Thread t1 = new Thread(obj1);
Thread t2 = new Thread(obj2);

t1.start();
t2.start();
	}

}
