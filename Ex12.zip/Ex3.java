package com;

import java.io.IOException;

public class Ex3 extends Thread {
	
	boolean stop = false;
	

	public void run() {
		for(int i=1;i<=1000000;i++) {
			System.out.println(+i);
			if(stop)return;
		}
	}

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

Ex3 ex3 = new Ex3();
Thread t = new Thread(ex3);
t.start();
System.in.read();


ex3.stop = true;

	}

}
