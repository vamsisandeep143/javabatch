package com;

//import java.util.Objects;

public class bookticket extends Thread {
	Object train,comp;
	public bookticket(Object train, Object comp) {
		super();
		this.train = train;
		this.comp = comp;
	}

	public void run() {
		synchronized(train){
			System.out.println("Booking ticket locked");
			try {
				Thread.sleep(150);
			
				
			}
			catch(InterruptedException e) {
				
			}
			System.out.println("Booking ticket now wait to lock on the compartment");
			synchronized(comp) {
				System.out.println("bookedTicket locked on the thread");
			}
		}
	}
}

