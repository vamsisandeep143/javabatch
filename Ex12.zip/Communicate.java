package com;

public class Communicate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		producer prod = new producer();
		consumer con = new consumer(prod);
		
		Thread t = new Thread(prod);
		Thread t1 = new Thread(con);
		
		t.start();
		t1.start();
	}

}
