package com;

public class producer extends Thread {
StringBuffer sb;
//dataprodover will be true when the data production is over
boolean dataprodover = false;

producer(){
	sb = new StringBuffer(); //allots memory
	
}
public void run(){
	//
	for(int i =1;i<=10;i++) {
		try {
			sb.append(i+"");
			
			Thread.sleep(10);
			
			System.out.println("appending");
			}
		catch(Exception e){}
		
	}
	
	dataprodover = true;
}
}
