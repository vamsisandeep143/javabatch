package com;

public class consumer extends Thread {
	
	producer prod;
	
	consumer(producer prod){
		this.prod = prod;
		
	}
	
	public void run ()
	
	{
		
		try {
			while(!prod.dataprodover) {
				Thread.sleep(10);
				
			}
			
		}catch(Exception e) {
			
		}
		
		System.out.println(prod.sb);
		
		
		
		
		
	}

}
