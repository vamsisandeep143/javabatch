package com;

//consumer will informed immediately when the data production is over 
public class producer1 extends Thread {

	
StringBuffer sb;

producer1(){
	sb = new StringBuffer();
}

public void run()
{
synchronized (sb) {
	for(int i=1;i<=10;i++) {
		try {
			sb.append(i+ ":");
			Thread.sleep(100);
	System.out.println("attending");		
			
		}
		catch(Exception e) {
			
		}
		sb.notify();
	}
}	
}
}
