package com;
public class Ex10 extends Thread {
	
	int count = 0;  //this counts numbers
	
	public void run() {
		for(int i=1;i<=10000;i++) {
			count++;
		}
			//display the thread has completed counting and its priority
			System.out.println("completed thread:"+ Thread.currentThread().getName());
			System.out.println("Its priority :" +Thread.currentThread().getPriority());
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ex10 e = new Ex10();
		 
		Thread t1 = new Thread(e,"one");
		Thread t2 = new Thread(e,"two");
		
		
		t1.setPriority(2);
		t2.setPriority(Thread.NORM_PRIORITY);
		
		t1.start();
		t2.start();
	}

}
