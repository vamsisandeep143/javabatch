package com;

public class consumer1 extends Thread {
	producer1 prod1;
	
	
	public consumer1(producer1 prod1) {
		super();
		this.prod1 = prod1;
	}

	
	public void run() {
		
		synchronized (prod1.sb) {
			
			try {
				
				prod1.sb.wait();
				System.out.println("sandeep");
			}
			catch(Exception ex) {}
			System.out.println(prod1.sb);	
		}
		
	}
	
	
	
	

}
