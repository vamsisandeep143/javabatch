package com;

public class Communicate1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		producer1 prod = new producer1();
		consumer1 con = new consumer1(prod);                                                                   
		
		
		Thread t = new Thread(prod);
		Thread t1 = new Thread(con);
		
		t1.start();
		t.start();
		
	}

}
