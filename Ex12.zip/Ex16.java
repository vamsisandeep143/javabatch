package com;
import java.util.concurrent.*;

public class Ex16 implements Runnable{
	
	private int taskno;

	public Ex16(int taskno) {
		super();
		this.taskno = taskno;
	}
	public void run() {
		for(int i=0;i<=100;i+=25) {
			String name = Thread.currentThread().getName();
			//display the thread name that performs the task
			
			System.out.println(name+"completed task" +taskno+"by"+i+"percent.");
			try {
				Thread.sleep(3000);
			}
			catch(InterruptedException ie) {
				
			}
		}
			
			
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      ExecutorService es = Executors.newFixedThreadPool(2);
      Ex16 e[] = new Ex16[4];
      
      for(int i=0;i<4; i++) {
    	  e[i] = new Ex16(i);
    	  es.execute( e[i]);
      }
      es.shutdown();
	}

}
