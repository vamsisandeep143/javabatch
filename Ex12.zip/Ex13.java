package com;

public class Ex13 extends Thread {
	public void run() {
		
		System.out.println("I am a cancellation thread");
	}
}
