package com;
// This is the inefficent way of communication
public class Ex9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
