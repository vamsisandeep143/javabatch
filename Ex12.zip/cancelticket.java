package com;

public class cancelticket extends Thread {

	Object train,comp;
	
	cancelticket(Object train,Object comp){
		
		this.train = train;
		this.comp = comp;
		
	}
	public void run() {
		synchronized(train) {
			
			System.out.println("cancelticket locked on compartment");
		    try {
		    	Thread.sleep(200);
		    	
		    }
		    catch(InterruptedException e) {
		    	
		    }
		System.out.println("cancelticket now wait to lock the train ");
		synchronized(comp) {
			System.out.println("cancelticket locked on the thread");
		}
		
		}
	}
}
