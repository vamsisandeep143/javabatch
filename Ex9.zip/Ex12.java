package com;

public class Ex12 extends Thread {

	public void run() {
		
		System.out.println("I am a reservation thread");
	}
}
