package com;
// creating a basic class and run it
public class Ex2 extends Thread {
	
	public void run() {
		for(int i=1;i<3;i++) {
			System.out.println(+i);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Ex2 ex2 = new Ex2();
Thread t = new Thread(ex2);
Thread t2 = new Thread(ex2);
t.start();
t2.start();

	}

}
