package com;

//import java.util.Objects;

public class DeadLocksituation extends Thread {
	Object train,comp;
	public DeadLocksituation(Object train, Object comp) {
		super();
		this.train = train;
		this.comp = comp;
	}

	public void run() {
		synchronized(train){
			System.out.println("Booking ticket locked");
			try {
				Thread.sleep(1500);
				
			}
		}
	}
		
	private void Synchronized(Object train2) {
		// TODO Auto-generated method stub
		
	}

	/*
	 * public DeadLocksituation(Train t, Compartment c) { super(); this.t = t;
	 * this.c = c; }
	 */
 
	/*
	 * Train t = new Train(); Compartment c = new Compartment();
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
