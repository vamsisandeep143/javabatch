package com;

public class Ex11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Ex12 e = new Ex12();
    Ex13 e1 = new Ex13();
    
    ThreadGroup tg = new ThreadGroup("First group");

    Thread t1 = new Thread(tg,e,"First thread");
    Thread t2 = new Thread(tg,e,"second thread");
    
    ThreadGroup tg1 = new ThreadGroup(tg,"secound group");
    
    Thread t3 = new Thread(tg1,e1," third thread");
    Thread t4 = new Thread(tg1,e1,"fourth thread");
    
    
    // find the parent group
    
    System.out.println("parent of tg1"+tg1.getParent());
    
    tg1.setMaxPriority(7);
    System.out.println("Thread group of t1 "+t1.getThreadGroup());
    System.out.println("Thread group of t3 "+t3.getThreadGroup());
    
    
    t1.start();
    t2.start();
    t3.start();
    t4.start();
    
    
    System.out.println("no of threads actively running     "+tg.activeCount());
    
    
    
    
    
    
    
    
	}

}
