package com;

public class producer extends Thread {
StringBuffer sb;

boolean dataprodover = false;

producer(){
	sb = new StringBuffer(); //allots memory
	
}
public void run(){
	//
	for(int i =1;i<=10;i++) {
		try {
			sb.append(i+"");
			Thread.sleep(1000);
			System.out.println({"appending");
			
			
			
			
			
			
			
			
			{
		}
	}
	
}
}
