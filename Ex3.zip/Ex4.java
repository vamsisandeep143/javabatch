package com;

public class Ex4 implements Runnable {
	
	public void run() {
		task1();
		task2();
		task3();
	}

	void task1() {
		System.out.println("task1");
	}
	
	void task2() {
		System.out.println("task2");
	}
	
	void task3() {
		System.out.println("task3");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ex4 ex4 = new Ex4();
		Thread th = new Thread(ex4);
		th.start();
	}

}
