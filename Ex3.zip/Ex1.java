package com;
// to find the currently running thread in a program
public class Ex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("Let us find the current thread");
Thread t = Thread.currentThread();
System.out.println("current thread" + t);
System.out.println("Its name is"+t.getName());
	}

}
