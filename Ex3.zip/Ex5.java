//Two threads performing two tasks at the same time.
package com;
public class Ex5 implements Runnable {
	String str;
	public Ex5(String str) {
		super();
		this.str = str;
	}
	public void run() {
		
		System.out.println("sandeep");
		for(int i = 1;i<=10;i++) {
			System.out.println("sandeep1");
			System.out.println(str+ ": "+i );
			try {
				Thread.sleep(2000);			
			}   catch(InterruptedException ie)  {
				ie.printStackTrace();
			}
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Ex5 e = new Ex5("cut the ticket");
Ex5 e1 = new Ex5("Show the ticket");

Thread t1 = new Thread(e);
Thread t2 = new Thread(e1);

t1.start();
t2.start();
	}
}