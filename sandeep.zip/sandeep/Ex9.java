package sandeep;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

public class Ex9 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
// to read string from keyboard
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String str;
		FileWriter fw = new FileWriter("B:\\writetest.txt");
		
		// read the strings and store in the file till exit is typed
		
		System.out.println("Enter the data");
		while(!(str = br.readLine()).equals("exit")) {
			fw.write(str + "\n");
		}
		fw.close();
	}

}
