package sandeep;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class Ex15 {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		FileInputStream fis = new FileInputStream("objfile");
		ObjectInputStream ois = new ObjectInputStream(fis);
		try {
			Ex13 e;
			while((e = (Ex13) ois.readObject()) != null) {
				e.displaydata();
			}
		}
		catch(EOFException ee) {
			System.out.println("End of the file reached");
		}
		finally {
			ois.close();
		}
		
	}

}
