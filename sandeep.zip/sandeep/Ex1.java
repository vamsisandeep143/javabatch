package sandeep;
//create a text file using Fileoutput Stream
import java.io.*;
public class Ex1 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
 DataInputStream dat = new DataInputStream(System.in);
 //FileOutputStream fout = new FileOutputStream("myfile.txt");
 FileOutputStream fout1 = new FileOutputStream("myfile1.txt",true);
 
 System.out.println(" Enter the @ at the end");
 
 char ch;
 
 while((ch=(char)dat.read())!='@') {
	 fout1.write(ch);
 }
 fout1.close();
	}

}
