package sandeep;
//create a text file using Fileoutput Stream
import java.io.*;
public class Ex2 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
 DataInputStream dat = new DataInputStream(System.in);
 FileOutputStream fout = new FileOutputStream("myfile.txt");
 BufferedOutputStream bout = new BufferedOutputStream(fout,1024);
 //FileOutputStream fout1 = new FileOutputStream("myfile.txt",true);
 
 System.out.println(" Enter the @ at the end");
 
 char ch;
 
 while((ch=(char)dat.read())!='@') {
	 bout.write(ch);
 }
 bout.close();
	}

}
