package sandeep;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.InflaterInputStream;

public class Ex12 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
FileInputStream fr = new FileInputStream("B:\\kishore.txt");
FileOutputStream fp = new FileOutputStream("B:\\kishore1.txt");
InflaterInputStream fl = new InflaterInputStream(fr);

int data;
while((data = fl.read())!= -1) {
	fp.write(data);
}
fp.close();
fl.close();

	}

}
