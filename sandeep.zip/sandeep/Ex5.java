package sandeep;
import java.io.*;
public class Ex5 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
FileInputStream fin = new FileInputStream("B:\\testbox.txt");
System.out.println("Files contents");
// Reads characters from fileinputStream and write them to monitor Repeat till the end of file

int ch;
while((ch=fin.read())!= -1) {
	System.out.print((char)ch);
}
fin.close();

  String str = fin.toString();
  System.out.println(str);
 
	}

}
