package sandeep;
import java.io.*;
import java.util.*;
public class Ex14 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

FileOutputStream fos = new FileOutputStream("objfile");

ObjectOutputStream oos = new ObjectOutputStream(fos);

System.out.println(" how many employees");

int n = Integer.parseInt(br.readLine());

for(int i=0;i<n;n++) {
	Ex13 e = new Ex13();
	e.getData();
	oos.writeObject(e);
}

oos.close();
	}

}
