package sandeep;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.Calendar;

public class Ex13 implements Serializable {
	
	int id;
	String name;
	float sal;
	Calendar doj;
	
	void displaydata() {
		
		int yy = doj.get(Calendar.YEAR);
		int mm = doj.get(Calendar.MONTH);
		mm++;
		int dd = doj.get(Calendar.DATE);
		System.out.printf("%-10d %s %10.2f %2d-%4d\n", id,name,sal,dd,mm,yy);
	}
	
	void getData() throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the emp Id");
		id = Integer.parseInt(br.readLine());
		System.out.println("Enter Name :");
		name = br.readLine();
		System.out.println("Enter the Salary of the Employee");
		sal = Float.parseFloat(br.readLine());
		
		
		// Accept the date of joining from the keyboard
		
		System.out.println("Enter the date of joining");
		System.out.println("Enter day");
		int dd = Integer.parseInt(br.readLine());
		
		System.out.println("Enter Month");
		int mm = Integer.parseInt(br.readLine());
		mm--;
		
		System.out.println("Enter year");
		int yy = Integer.parseInt(br.readLine());
		
		doj = Calendar.getInstance();
		doj.set(yy, mm,dd);
				
		
		
		
		
		
		
		
		
	}
	

}
