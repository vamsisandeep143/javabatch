package sandeep;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Ex10 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		String str;
		// connect the filereader to the textfile
		FileReader fr = new FileReader("B:\\readtest.txt");
		BufferedReader br = new BufferedReader(fr);
		
		while((str=br.readLine())!= null) {
			System.out.println(str);
		}
		fr.close();
	}

}
