package sandeep;

import java.io.FileWriter;
import java.io.IOException;

public class Ex7 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		String str = "This is a book on java"+"\n I am a leaner of java.";
		
		// attach file to fileWriter
		FileWriter fw = new FileWriter("B:\\readtest1.txt");
		// Read character wise from the string and write into filewriter
		
		for(int i = 0;i<str.length();i++) {
			fw.write(str.charAt(i));
		}
		fw.close();
	}

}
