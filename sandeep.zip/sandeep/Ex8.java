package sandeep;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Ex8 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		
		int ch;
		FileReader fr = null;
		
		// check for the file exist or not.
		
		try {
			fr = new FileReader("B:\\readtest.txt");
		}
		catch (FileNotFoundException fe) {
			fe.printStackTrace();
			System.out.println("file not found");
			return;
		}
		
		//read from file reader till the end of the file
		while((ch=fr.read())!= -1) {
			System.out.println((char)ch);
		}
		fr.close();
	}

}
