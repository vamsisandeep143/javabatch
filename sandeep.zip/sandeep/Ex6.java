package sandeep;
import java.io.*;

public class Ex6 {

	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		// to accept the filename from keyboard	
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the file name");
		String fname = br.readLine();
		
		
		// attach the file input to file input stream 
		
		FileInputStream fin = null;
		
		try {
			fin = new FileInputStream(fname);
		}
		catch(FileNotFoundException fe) {
			System.out.println("file not found");
			fe.printStackTrace();
			return;
		}
		
		//attach the fileInputStream to bufferedReader
		
		BufferedInputStream br1= new BufferedInputStream(fin);
		System.out.print("file contents");
		
		int ch;
		while((ch=br1.read())!= -1) {
			
			System.out.print((char)ch);
			
			
			
		}
		br1.close();
	}

}
