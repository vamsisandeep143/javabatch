package sandeep;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.DeflaterOutputStream;

public class Ex11 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		FileInputStream fis= new FileInputStream("B:\\sandeep.txt");
		FileOutputStream fout = new FileOutputStream("B:\\kishore.txt");
		
		DeflaterOutputStream dos = new DeflaterOutputStream(fout);
		
		
		int data;
		while((data = fis.read()) != -1) {
			dos.write(data);
		}
		
		fis.close();
		dos.close();
	

	}

}
